function EventsSection(){
    return (
        <h1>hey</h1>
    )
}

export default EventsSection